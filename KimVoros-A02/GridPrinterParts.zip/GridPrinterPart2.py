#------------------------------------#
# Title: Grid Printer Part 2
# Desc: This program writes a specific grid given n input
# Change Log: (Who, When, What)
# Kim Voros, 1/21/2019, Wrote program
# ------------------------------------#

#
# + - - - - + - - - - +
# |         |         |
# |         |         |
# |         |         |
# |         |         |
# + - - - - + - - - - +
# |         |         |
# |         |         |
# |         |         |
# |         |         |
# + - - - - + - - - - +


#Data
#make variables building blocks that can be easily combined rather than hard coding
a = '+'
b = ' -'
c = ' '
d = '|'
e = '  '

#these are my per line building blocks

#print(((a + n * b + c) * 2) + a)
#print(((d + n * e + c) * 2) + d)


#processing
# define print grid function and print results
def print_grid(n):
    for i in range (n):
        if i == 0 or i == n//2 or i == n-1:
            print(((a + n * b + c) * 2) + a)
        else:
            print(((d + n * e + c) * 2) + d)




#presentation
#print results
print_grid(9)
