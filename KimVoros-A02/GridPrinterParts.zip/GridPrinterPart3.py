#------------------------------------#
# Title: Grid Printer Part 3
# Desc: This program writes a matrix given x,y input
# Change Log: (Who, When, What)
# Kim Voros, 1/21/2019, Wrote program
# ------------------------------------#

#
# + - - - - + - - - - +
# |         |         |
# |         |         |
# |         |         |
# |         |         |
# + - - - - + - - - - +
# |         |         |
# |         |         |
# |         |         |
# |         |         |
# + - - - - + - - - - +


#Data
#make variables building blocks that can be easily combined rather than hard coding
a = '+'
b = ' -'
c = ' '
d = '|'
e = '  '

#these are my per line building blocks
#def test(x,y):
#    print(((a + x * b + c) * 2) + a)
#    print(((d + x * e + c) * 2) + d)

#test(11,12)
#processing
# define print grid function and print results
def print_grid(x,y):
    print(((a + y * b + c) * y) + a)
    for i in range(x):
        for i in range (y):
            if i == y-1:
                print(((a + y * b + c) * y) + a)
            else:
                print(((d + y * e + c) * y) + d)


#presentation
#print results
print_grid(3,2)
